Lex版本： flex 2.5.35
作業平台： Windows 10 1607 64-bit
執行方式： Bash on Windows (Linux KELVIN-PC 3.4.0+ #1 PREEMPT Thu Aug 1 17:06:05 CST 2013 x86_64 x86_64 x86_64 GNU/Linux)

你/妳如何處理這份規格書上的問題：
	Google相關資料，了解LEX的運作方式以及撰寫規則，並對JAVA語言進行初步的理解。

你/妳寫這個作業所遇到的問題：
	LEX語法和架構陌生
	不了解JAVA語言的格式
	作業要求使用C語言編譯，許久未碰觸C

執行結果：(以append形式輸出)
Line: 2, 1st char: 1, "public" is a "reserved word".
Line: 2, 1st char: 8, "class" is a "reserved word".
Line: 2, 1st char: 14, "Test1" is a "ID".
Line: 2, 1st char: 20, "{" is a "symbol".
Line: 3, 1st char: 5, "public" is a "reserved word".
Line: 3, 1st char: 12, "static" is a "reserved word".
Line: 3, 1st char: 19, "int" is a "reserved word".
Line: 3, 1st char: 23, "add" is a "ID".
Line: 3, 1st char: 26, "(" is a "symbol".
Line: 3, 1st char: 27, "int" is a "reserved word".
Line: 3, 1st char: 31, "a" is a "ID".
Line: 3, 1st char: 32, "," is a "symbol".
Line: 3, 1st char: 34, "int" is a "reserved word".
Line: 3, 1st char: 38, "b" is a "ID".
Line: 3, 1st char: 39, ")" is a "symbol".
Line: 3, 1st char: 41, "{" is a "symbol".
Line: 4, 1st char: 9, "return" is a "reserved word".
Line: 4, 1st char: 16, "a" is a "ID".
Line: 4, 1st char: 18, "+" is a "operator".
Line: 4, 1st char: 20, "b" is a "ID".
Line: 4, 1st char: 21, ";" is a "symbol".
Line: 5, 1st char: 5, "}" is a "symbol".
Line: 7, 1st char: 5, "public" is a "reserved word".
Line: 7, 1st char: 12, "static" is a "reserved word".
Line: 7, 1st char: 19, "void" is a "reserved word".
Line: 7, 1st char: 24, "main" is a "ID".
Line: 7, 1st char: 28, "(" is a "symbol".
Line: 7, 1st char: 29, ")" is a "symbol".
Line: 7, 1st char: 31, "{" is a "symbol".
Line: 9, 1st char: 9, "int" is a "reserved word".
Line: 9, 1st char: 13, "c" is a "ID".
Line: 9, 1st char: 14, ";" is a "symbol".
Line: 10, 1st char: 9, "int" is a "reserved word".
Line: 10, 1st char: 13, "a" is a "ID".
Line: 10, 1st char: 15, "=" is a "operator".
Line: 10, 1st char: 17, "5" is a "Integer".
Line: 10, 1st char: 18, ";" is a "symbol".
Line: 11, 1st char: 9, "c" is a "ID".
Line: 11, 1st char: 11, "=" is a "operator".
Line: 11, 1st char: 13, "add" is a "ID".
Line: 11, 1st char: 16, "(" is a "symbol".
Line: 11, 1st char: 17, "a" is a "ID".
Line: 11, 1st char: 18, "," is a "symbol".
Line: 11, 1st char: 20, "10" is a "Integer".
Line: 11, 1st char: 22, ")" is a "symbol".
Line: 11, 1st char: 23, ";" is a "symbol".
Line: 12, 1st char: 9, "if" is a "reserved word".
Line: 12, 1st char: 12, "(" is a "symbol".
Line: 12, 1st char: 13, "c" is a "ID".
Line: 12, 1st char: 15, ">" is a "operator".
Line: 12, 1st char: 17, "10" is a "Integer".
Line: 12, 1st char: 19, ")" is a "symbol".
Line: 13, 1st char: 13, "print" is a "ID".
Line: 13, 1st char: 18, "(" is a "symbol".
Line: 13, 1st char: 20, "c = " is a "string".
Line: 13, 1st char: 26, "+" is a "operator".
Line: 13, 1st char: 28, "-" is a "operator".
Line: 13, 1st char: 29, "c" is a "ID".
Line: 13, 1st char: 30, ")" is a "symbol".
Line: 13, 1st char: 31, ";" is a "symbol".
Line: 14, 1st char: 9, "else" is a "reserved word".
Line: 15, 1st char: 13, "print" is a "ID".
Line: 15, 1st char: 18, "(" is a "symbol".
Line: 15, 1st char: 19, "c" is a "ID".
Line: 15, 1st char: 20, ")" is a "symbol".
Line: 15, 1st char: 21, ";" is a "symbol".
Line: 16, 1st char: 9, "print" is a "ID".
Line: 16, 1st char: 14, "(" is a "symbol".
Line: 16, 1st char: 16, "" is a "string".
Line: 16, 1st char: 28, ")" is a "symbol".
Line: 16, 1st char: 29, ";" is a "symbol".
Line: 18, 1st char: 5, "}" is a "symbol".
Line: 20, 1st char: 1, "}" is a "symbol".
Line: 21, 1st char: 1, "// this is a comment // line */ /* with /* delimiters */ before the end" is a "comment".
Line: 23, 1st char: 1, "public" is a "reserved word".
Line: 23, 1st char: 8, "class" is a "reserved word".
Line: 23, 1st char: 14, "Test2" is a "ID".
Line: 23, 1st char: 20, "{" is a "symbol".
Line: 24, 1st char: 5, "int" is a "reserved word".
Line: 24, 1st char: 9, "i" is a "ID".
Line: 24, 1st char: 11, "=" is a "operator".
Line: 24, 1st char: 13, "-100" is a "Integer".
Line: 24, 1st char: 17, ";" is a "symbol".
Line: 25, 1st char: 5, "double" is a "reserved word".
Line: 25, 1st char: 12, "d" is a "ID".
Line: 25, 1st char: 14, "=" is a "operator".
Line: 25, 1st char: 16, "12.25e+6" is a "real".
Line: 25, 1st char: 24, ";" is a "symbol".
Line: 27, 1st char: 5, "public" is a "reserved word".
Line: 27, 1st char: 12, "static" is a "reserved word".
Line: 27, 1st char: 19, "void" is a "reserved word".
Line: 27, 1st char: 24, "main" is a "ID".
Line: 27, 1st char: 28, "(" is a "symbol".
Line: 27, 1st char: 29, ")" is a "symbol".
Line: 27, 1st char: 31, "{" is a "symbol".
Line: 28, 1st char: 1, "/* this is a comment // line with some /* and
// delimiters */" is a "comment".
Line: 30, 1st char: 5, "}" is a "symbol".
Line: 31, 1st char: 1, "}" is a "symbol".
Line: 33, 1st char: 1, "public" is a "reserved word".
Line: 33, 1st char: 8, "class" is a "reserved word".
Line: 33, 1st char: 14, "Test3" is a "ID".
Line: 33, 1st char: 20, "{" is a "symbol".
Line: 34, 1st char: 5, "int" is a "reserved word".
Line: 34, 1st char: 9, "A" is a "ID".
Line: 34, 1st char: 10, ";" is a "symbol".
Line: 35, 1st char: 5, "int" is a "reserved word".
Line: 35, 1st char: 9, "a" is a "ID".
Line: 36, 1st char: 5, "double" is a "reserved word".
Line: 36, 1st char: 12, "b" is a "ID".
Line: 36, 1st char: 13, ";" is a "symbol".
Line: 37, 1st char: 5, "double" is a "reserved word".
Line: 37, 1st char: 12, "A" is a "ID".
Line: 37, 1st char: 13, ";" is a "symbol".
Line: 39, 1st char: 5, "public" is a "reserved word".
Line: 39, 1st char: 12, "Test3" is a "ID".
Line: 39, 1st char: 17, "(" is a "symbol".
Line: 39, 1st char: 18, ")" is a "symbol".
Line: 39, 1st char: 20, "{" is a "symbol".
Line: 40, 1st char: 9, "a" is a "ID".
Line: 40, 1st char: 11, "=" is a "operator".
Line: 40, 1st char: 13, "1" is a "Integer".
Line: 40, 1st char: 14, ";" is a "symbol".
Line: 41, 1st char: 9, "A" is a "ID".
Line: 41, 1st char: 11, "=" is a "operator".
Line: 41, 1st char: 13, "2" is a "Integer".
Line: 41, 1st char: 14, ";" is a "symbol".
Line: 42, 1st char: 9, "b" is a "ID".
Line: 42, 1st char: 11, "=" is a "operator".
Line: 42, 1st char: 13, "-1.2" is a "real".
Line: 42, 1st char: 17, ";" is a "symbol".
Line: 43, 1st char: 5, "}" is a "symbol".
Line: 44, 1st char: 1, "}" is a "symbol".
The symbol table contains:
Test1
add
a
b
main
c
print
Test2
i
d
Test3
A
