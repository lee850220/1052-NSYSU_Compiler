
public class Test1 {
    public static int add(int a, int b) {
        return a + b;
    }

    public static void main() {

        int c;
        int a = 5;
        c = add(a, 10);
        if (c > 10)
            print("c = " + -c);
        else
            print(c);
        print("Hello World");

    }

}
// this is a comment // line */ /* with /* delimiters */ before the end

public class Test2 {
    int i = -100;
    double d = 12.25e+6;

    public static void main() {
/* this is a comment // line with some /* and
// delimiters */
    }
}

public class Test3 {
    int A;    
    int a
    double b;
    double A;

    public Test3() {
        a = 1;
        A = 2;
        b = -1.2;
    }
}
