
public class Test3 {
    int A;    
    int a
    double b;
    double A;

    public Test3() {
        a = 1;
        A = 2;
        b = -1.2;
    }
}
